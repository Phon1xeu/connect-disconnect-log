AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    deferrals.defer()
    Wait(0)

    local identifiers = GetPlayerIdentifiers(src)
    local license, ip = "N/A", "N/A"

    for _, id in pairs(identifiers) do
        if string.find(id, "license:") then
            license = id
        elseif string.find(id, "ip:") then
            ip = id:gsub("ip:", "")
        end
    end

    deferrals.update("Joining...")

    local message = {
        username = "Connect log",
        avatar_url = Config.Thumbnail,
        embeds = {{
            title = "🔵 Player connected",
            color = 3145645,
            description = string.format("**Name:** %s\n\n||**IP Adress:** %s||\n||**License:** %s||", name, ip, license),
            footer = {
                text = os.date("Joined: %d.%m.%Y %H:%M:%S"),
                icon_url = Config.Thumbnail
            },
            image = {
                url = Config.Image
            }
        }}
    }

    PerformHttpRequest(Config.ConnectWebhook, function() end, "POST", json.encode(message), { ["Content-Type"] = "application/json" })

    deferrals.done()
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local name = GetPlayerName(src)
    local identifiers = GetPlayerIdentifiers(src)
    local license, ip = "N/A", "N/A"

    for _, id in pairs(identifiers) do
        if string.find(id, "license:") then
            license = id
        elseif string.find(id, "ip:") then
            ip = id:gsub("ip:", "")
        end
    end

    local message = {
        username = "Disconnect log",
        avatar_url = Config.Thumbnail,
        embeds = {{
            title = "🔴 Player disconnected",
            color = 16711680,
            description = string.format("**Name:** %s\n**Reason:** %s\n\n||**IP Adress:** %s||\n||**License:** %s||", name, reason, ip, license),
            footer = {
                text = os.date("Disconnected: %d.%m.%Y %H:%M:%S"),
                icon_url = Config.Thumbnail
            },
            image = {
                url = Config.Image
            }
        }}
    }

    PerformHttpRequest(Config.DisconnectWebhook, function() end, "POST", json.encode(message), { ["Content-Type"] = "application/json" })
end)
