fx_version 'cerulean'
game 'gta5'

author 'Phon1xeu'
description 'Connect/Disconnect log'
version '1.0.2'

server_script 'config.lua'
server_script 'server.lua'
