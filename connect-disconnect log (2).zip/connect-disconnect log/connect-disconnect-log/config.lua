Config = {}


Config.ConnectWebhook = "Your_Wehook"
Config.DisconnectWebhook = "Your_Wehook"


Config.Thumbnail = "https://link-to-your-thumbnail.png"
Config.Image = "https://link-na-big-image.png"
