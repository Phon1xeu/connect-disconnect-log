# 🔗 FiveM Connect & Disconnect Discord Logger

A simple yet powerful FiveM server-side script that logs player connections and disconnections to **separate Discord webhooks**. The log includes the player's name, license, and IP address (hidden in spoiler tags for privacy). The script is fully configurable with custom webhook URLs, thumbnails, and images.

---

## ✨ Features

- Logs **player connecting** and **disconnecting** events.
- Sends detailed messages to **custom Discord webhooks**.
- Includes:
  - Player name
  - IP address (in Discord spoiler)
  - Rockstar license (in Discord spoiler)
  - Disconnect reason (if applicable)
- Easy configuration via `config.lua`.
- Support for **custom thumbnails and images** in embeds.

---

## 🧩 Installation

1. **Download** or clone this repository.
2. Place it in your `resources` folder (e.g., `resources/[local]/fivem-discord-logger`).
3. Add this line to your `server.cfg`:
4. Edit the `config.lua` file and set your webhook URLs and images.

---

## ⚙️ Configuration (`config.lua`)

```lua
Config = {}

-- Discord Webhooks
Config.ConnectWebhook = "YOUR_CONNECT_WEBHOOK_URL"
Config.DisconnectWebhook = "YOUR_DISCONNECT_WEBHOOK_URL"

-- Embed Images
Config.Thumbnail = "https://your-thumbnail-image-link.png"
Config.Image = "https://your-main-image-link.png"
